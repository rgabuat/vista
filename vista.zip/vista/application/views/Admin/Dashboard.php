<div class="container-fluid">
    <div class="row">
        <div class="col-12">
                <div class="row">
                <div class="col-sm-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                        <p class="text-center"><span><b>Brands</b></span></p>
                            <h1 class="text-center"><?= $brands_count;?></h1>
                        </div>
                        <div class="card-footer text-center"><a href="#">Click me</a></div>
                    </div>
                </div>
                <div class="col-sm-4 mb-3">
                    <div class="card">
                            <div class="card-body">
                            <p class="text-center"><span><b>Cars</b></span></p>
                                <h1 class="text-center"><?= $cars_count?></h1>
                            </div>
                            <div class="card-footer text-center"><a href="#">Click me</a></div>
                        </div>
                </div>
                <div class="col-sm-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                        <p class="text-center"><span><b>Reservations</b></span></p>
                            <h1 class="text-center">0</h1>
                        </div>
                        <div class="card-footer text-center"><a href="#">Click me</a></div>
                    </div>
                </div>
                <div class="col-sm-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                        <p class="text-center"><span><b>Reports</b></span></p>
                            <h1 class="text-center">0</h1>
                        </div>
                        <div class="card-footer text-center"><a href="#">Click me</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>