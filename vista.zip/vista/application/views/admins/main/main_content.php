
<div class="content">

<?= $main_content?>

</div>
<!-- content -->
