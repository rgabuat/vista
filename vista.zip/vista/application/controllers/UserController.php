<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserController extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('Admin_model');
        $this->load->model('User_model');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->library(array('email'));
    }

    public function send_email()
    {
        // $config = array();
        // $config['protocol'] = 'smtp';
        // $config['smtp_host'] = 'ss://smtp.googlemail.com';
        // $config['smtp_port'] = '465';
        // $config['smtp_user'] = 'johncarlgabuat@gmail.com';
        // $config['smtp_pass'] = 'i8e3vcrf7h012256789';
        // $config['smtp_crpyto'] = 'ssl';
        // $config['mailtype'] = 'html';
        // $config['charset'] = 'iso-8859-1';
        // $config['wordwrap'] = TRUE;
        // $this->load->library('email');
        $config = array(
            'protocol' => 'smtp',
            'smtp_host' => 'smtp.gmail.com',
            'smtp_port' => 465,
            'smtp_user' => 'johncarlgabuat@gmail.com',
            'smtp_pass' => 'i8e3vcrf7h012256789',
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'newline' => '\r\n',
            'mailtype' => 'html'
        );

        // $this->email->initialize($config);
        // $this->email->set_newline('\r\n');

        $this->load->library('email', $config);
        // $this->email->set_mailtype("html");
        

        $this->email->from('johncarlgabuat@gmail.com', 'Your Name');
        $this->email->to('johncargabuat@gmail.com');
        $this->email->subject('This the test');
        $this->email->message('this is the test message');

        if($this->email->send())
        {
            echo 'Email sent';
        }
        else 
        {
            show_error($this->email->print_debugger());
        }
       
        // $message = 'Hello word !';
        // $this->load->library('email',$config);
        // $this->email->set_newline("\r\n");
        // $this->email->from('johncarlgabuat@gmail.com');
        // $this->email->to('johncarlgabuat@gmail.com');
        // $this->email->subject('Send Email Codeigniter:Send Mail');
        // $this->email->message($message);

        // if($this->email->send())
        // {
        //     echo 'Email sent';
        // }
        // else 
        // {
        //     show_error($this->email->print_debugger());
        // }
    }


	public function index($offset = null)
	{
        $limit = 6;
        if(!is_null($offset))
        {
            $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        }
		$data = array();

		// $data['results'] = $this->User_model->view_join_data($limit,$offset);
        $data['rowsz'] = $this->User_model->total_records_count();

       
        $config['base_url'] = base_url('UserController/index');
        $config['total_rows'] =  $this->User_model->get_Data($limit,$offset,$count=true);
        $config['uri_segment'] = 3;
        $config['per_page'] = $limit;

        $config['full_tag_open'] = '<ul class="pagination d-flex justify-content-center">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false ;
        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="page-item prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<liclass="page-item">';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<liclass="page-item">';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['attributes'] = ['class' => 'page-link'];
        $config['query_string_segment'] = 'page';
        // $config['page_query_string'] = true;
        // $config['use_page_numbers'] = true;

        $this->pagination->initialize($config);

        $data['slider'] = $this->User_model->view_join_data();
        $data['results'] = $this->User_model->get_Data($limit,$offset,$count=false);

        // echo json_encode($data['results']);

        $this->load->view('templates/header');
		$this->load->view('Home',$data);
        $this->load->view('templates/footer');
	}

    public function reserveValidation()
    {
        $data= array();
        $ids = $this->input->post('dataId');
        $startDate = $this->input->post('data_startDate');
        $endDate = $this->input->post('data_endDate');

        $from = strtotime($startDate);
        $formatted_from = date('Y-m-d H:i:s', $from);

        $to = strtotime($endDate);
        $formatted_to = date('Y-m-d H:i:s', $to);
        // echo $to;
        // echo $to;

        $data['rez'] = $this->User_model->getBooking($ids,$startDate,$endDate);

        if(empty($data['rez']))
        {
            echo json_encode('true');
        }
        else 
        {
            echo json_encode('null');
            // echo json_encode($data['rez']);
        }
        
    }

    public function view_vehicle($id)
    {
        $data = array();
		$data['results'] = $this->Admin_model->get_data_cars();
        $data['result'] = $this->User_model->view_Single_car($id);

        // $param['single_id'] = $id;
        // $param['date_from'] = $this->input->post('d_cdateform');
        // $param['date_to'] = $this->input->post('d_cdateto');

        // $data['rez'] = $this->User_model->getBooking($id,$param);

        // echo json_encode($param);

        $this->load->view('templates/header');
		$this->load->view('SingleCar',$data);
        $this->load->view('templates/footer');
    }

    public function reserverForm()
    {
        $data = array();
		// $data['results'] = $this->Admin_model->get_data_cars();
        // $data['result'] = $this->User_model->view_Single_car();
    
        $this->load->view('templates/header');
		$this->load->view('ReserveForm',$data);
        $this->load->view('templates/footer');
    }

  

    public function createBooking()
    {
        if(isset($_FILES['valid_id']['name']))
        {
            $path = $config['upload_path']  = 'uploads/imgs/';
            $config['allowed_types']        = '*';
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            // if(!is_dir('./uploads/'.$insert_id))
            // {
            //     mkdir('./uploads/'.$insert_id,0777,true);
            // }
            if (!$this->upload->do_upload('valid_id'))
            {
                echo $this->upload->display_errors();
            }
            else
            {
                $uploaded_img= $this->upload->data();
                $full_path = $path.$uploaded_img['file_name'];
                $param['valid_id'] = $full_path;
                echo $full_path;
            }
            
        }
        if(isset($_FILES['billing']['name']))
        {
            $path = $config['upload_path']  = 'uploads/imgs/';
            $config['allowed_types']        = '*';
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            // if(!is_dir('./uploads/'.$insert_id))
            // {
            //     mkdir('./uploads/'.$insert_id,0777,true);
            // }
            if (!$this->upload->do_upload('billing'))
            {
                echo $this->upload->display_errors();
            }
            else
            {
                $uploaded_img= $this->upload->data();
                $full_path = $path.$uploaded_img['file_name'];
                $param['billing'] = $full_path;
                echo $full_path;
            }
            
        }
        if(isset($_FILES['selfie']['name']))
        {
            $path = $config['upload_path']  = 'uploads/imgs/';
            $config['allowed_types']        = '*';
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            // if(!is_dir('./uploads/'.$insert_id))
            // {
            //     mkdir('./uploads/'.$insert_id,0777,true);
            // }
            if (!$this->upload->do_upload('selfie'))
            {
                echo $this->upload->display_errors();
            }
            else
            {
                $uploaded_img= $this->upload->data();
                $full_path = $path.$uploaded_img['file_name'];
                $param['selfie'] = $full_path;
                echo $full_path;
            }
            
        }


        $param['vh_id'] = $this->input->post('vechicle_id');
        $param['fname'] = $this->input->post('fname');
        $param['lname'] = $this->input->post('lname');
        $param['email'] = $this->input->post('email');
        $param['mobile'] = $this->input->post('mobile');
        $param['house_no'] = $this->input->post('house_no');
        $param['village'] = $this->input->post('village');
        $param['city'] = $this->input->post('city');
        $param['state'] = $this->input->post('state');
        $param['zip'] = $this->input->post('zip');
       
        $param['day'] = $this->input->post('d_day');
        $param['total'] = $this->input->post('d_total');
        $param['cname'] = $this->input->post('d_cname');
        $param['cmodel'] = $this->input->post('d_cmodel');
        $param['cyear'] = $this->input->post('d_cyear');
        $param['clocation'] = $this->input->post('d_clocation');
        $param['cdestination'] = $this->input->post('d_cdestination');
        
        $param['cdateform'] = $this->input->post('d_cdateform');
        $param['cdateto'] = $this->input->post('d_cdateto');

        // $start_Date = $this->input->post('d_cdateform');
        // $end_Date = $this->input->post('d_cdateto');
        
        // $start_Date = date("y-m-d h:i:sa");
        // $bookStart = strtotime($start_Date);

        // $end_Date = date("y-m-d h:i:sa");
        // $bookEnd = strtotime($end_Date);

        // $param['cdateform'] = $start_Date;
        // $param['cdateto'] = $end_Date;



        // $param['valid_id'] = $this->input->post('valid_id');
        // $param['biling'] = $this->input->post('biling');
        // $param['selfie'] = $this->input->post('selfie');
        
        $this->User_model->add_booking($param);
        
        echo json_encode($param);
        
    }

    public function contactInquiries()
    {
        $data = array();
        $data['FirstName'] = $this->input->post('Fname');
        $data['LastName'] = $this->input->post('Lname');
        $data['Email'] = $this->input->post('email');
        $data['Contact'] = $this->input->post('Contact');
        $data['Message'] = $this->input->post('inquiry');

        $this->User_model->insertInquiries($data);
        echo json_encode($data);
    }

    public function subscriber()
    {
        $data = array();
        $data['Name'] = $this->input->post('name');
        $data['Email'] = $this->input->post('email');

        $this->User_model->insertSubscriber($data);
        echo json_encode($data);
    }



}
    