<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CreatebrandController extends CI_Controller {

	// public function index()
	// {
        
    //     $this->load->view('Admin/template/header');
	// 	$this->load->view('Admin/Create_brand');
    //     $this->load->view('Admin/template/footer');
       
	// }

}

